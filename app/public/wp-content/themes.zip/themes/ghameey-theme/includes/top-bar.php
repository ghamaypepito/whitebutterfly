<div class="fl-page-bar">
	<div class="fl-page-bar-container container">
		<div class="fl-page-bar-row row">
			<?php FLTheme::top_bar_col1(); ?>
			<?php FLTheme::top_bar_col2(); ?>
		</div>
	</div>
</div><!-- .fl-page-bar -->