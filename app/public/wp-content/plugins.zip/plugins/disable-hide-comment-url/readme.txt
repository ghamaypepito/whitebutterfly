=== disable-hide-comment-url ===
Contributors: Sachin Khosla
Donate link: http://www.digimantra.com/
Tags: comments,wordpress,url,website,hide,disable,comment module
Requires at least: 2.0.2
Tested up to: 3.2.1
Stable tag: 1.0

Disable/Hide Comment URL lets you hide the URL/Website input field from the WordPress inbuilt comments block.

== Description ==

This plugin will allow you to remove the URL option from the comment box. This prevents automated bots to post spam links on your website. It helps your website retain the SEO Juice. 
This is a lightweight very simple plugin. No Javascript, ajax hack. 

== Installation ==

1. Download and unzip the file.
2. Upload the folder disable-hide-comment-url using FTP program into 'wp-content/plugins/' folder.
3. Activate the plugin and enjoy.

== Usage ==

Simply activate the plugin and the URL input text box will not appear. 

== Frequently Asked Questions ==
= How does it work ? =
It uses the WordPress 's inbuilt filter to disable the URL from the comment box. 
= Does it uses any JavaScript or CSS hack ? =
No.


== Screenshots ==
1. Showing a default comment box of WordPress Twenty Eleven theme, notice it does not have Website/URL option.
